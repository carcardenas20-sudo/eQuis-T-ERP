import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { SessionProvider, useSession } from "./components/providers/SessionProvider";
import { ThemeProvider } from "./components/providers/ThemeProvider";
import { ThemeToggle } from "./components/layout/ThemeToggle";
import BottomTabBar from "./components/layout/BottomTabBar";
import { AnimatePresence, motion } from "framer-motion";

import {
  Menu, X, LogOut, LayoutDashboard, ShoppingCart, Package, MapPin, Users,
  FileText, Settings, Building2, UserCheck, CreditCard, Receipt, ShoppingBag,
  BookOpen, ArrowRightLeft, ArrowLeftRight, Sparkles, Wallet, BarChart3,
  ChevronRight, ListChecks, Factory, Shirt, Palette, Wrench, Truck, Calculator,
  PackageCheck, TruckIcon, Clock, Warehouse, Eye
} from "lucide-react";

const comercialGroups = [
  {
    title: "Principal", items: [
      { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard, permissions: ["reports_basic"] },
      { title: "Punto de Venta", url: createPageUrl("POS"), icon: ShoppingCart, permissions: ["pos_sales"] },
      { title: "Asistente IA", url: createPageUrl("Assistant"), icon: Sparkles, permissions: ["agent_access"] },
    ]
  },
  {
    title: "Ventas", items: [
      { title: "Ventas", url: createPageUrl("Sales"), icon: FileText, permissions: ["sales_view"] },
      { title: "Cambios", url: createPageUrl("Exchanges"), icon: ArrowLeftRight, permissions: ["sales_view"] },
      { title: "Clientes", url: createPageUrl("Customers"), icon: UserCheck, permissions: ["customers_view"] },
      { title: "Créditos", url: createPageUrl("Credits"), icon: CreditCard, permissions: ["credits_view"] },
    ]
  },
  {
    title: "Inventario", items: [
      { title: "Productos", url: createPageUrl("Products"), icon: Package, permissions: ["products_view", "products_create"] },
      { title: "Inventario", url: createPageUrl("Inventory"), icon: MapPin, permissions: ["inventory_view"] },
      { title: "Auditorías", url: createPageUrl("InventoryAudits"), icon: MapPin, permissions: ["inventory_view"] },
      { title: "Traslados", url: createPageUrl("Transfers"), icon: ArrowRightLeft, permissions: ["inventory_transfer"] },
    ]
  },
  {
    title: "Compras", items: [
      { title: "Compras", url: createPageUrl("Purchases"), icon: ShoppingBag, permissions: ["purchases_view"] },
    ]
  },
  {
    title: "Finanzas", items: [
      { title: "Gastos", url: createPageUrl("Expenses"), icon: Receipt, permissions: ["expenses_view"] },
      { title: "Checklist de Gastos", url: createPageUrl("ExpenseChecklist"), icon: ListChecks, permissions: ["expenses_view"] },
      { title: "Cuentas por Pagar", url: createPageUrl("AccountsPayable"), icon: CreditCard, permissions: ["expenses_view"] },
      { title: "Pagos Planificados", url: createPageUrl("PlannedPayments"), icon: ListChecks, permissions: ["expenses_view"] },
      { title: "Conciliación", url: createPageUrl("ConciliacionPagos"), icon: ListChecks, permissions: ["accounting_view_transactions"] },
      { title: "Control de Efectivo", url: createPageUrl("CashControl"), icon: Wallet, permissions: ["accounting_view_transactions"] },
      { title: "Cuentas Bancarias", url: createPageUrl("BankAccounts"), icon: Building2, permissions: ["accounting_view_transactions"] },
      { title: "Reportes", url: createPageUrl("Reports"), icon: BarChart3, permissions: ["reports_basic"] },
    ]
  },
  {
    title: "Configuración", items: [
      { title: "Usuarios", url: createPageUrl("Users"), icon: Users, permissions: ["users_view"] },
      { title: "Sucursales", url: createPageUrl("Locations"), icon: Building2, permissions: ["locations_view"] },
      { title: "Configuración", url: createPageUrl("Settings"), icon: Settings, permissions: ["settings_system"] },
      { title: "Integración API", url: createPageUrl("IntegracionAPI"), icon: Sparkles, permissions: [] },
      { title: "Tutoriales", url: createPageUrl("Tutorials"), icon: BookOpen, permissions: [] },
    ]
  },
];

const produccionGroups = [
  {
    title: "Producción", items: [
      { title: "Dashboard Producción", url: createPageUrl("Prod_Dashboard"), icon: LayoutDashboard, permissions: ["produccion_view"] },
      { title: "Remisiones", url: createPageUrl("Prod_Remisiones"), icon: Truck, permissions: ["produccion_view"] },
      { title: "Planificador", url: createPageUrl("Prod_PlanificacionRemisiones"), icon: ListChecks, permissions: ["produccion_view"] },
      { title: "Asignaciones", url: createPageUrl("Prod_AsignacionesIndividualesPage"), icon: UserCheck, permissions: ["produccion_view"] },
      { title: "Operaciones", url: createPageUrl("Prod_Operaciones"), icon: Wrench, permissions: ["produccion_view"] },
    ]
  },
  {
    title: "Materiales", items: [
      { title: "Materias Primas", url: createPageUrl("Prod_MateriasPrimas"), icon: Package, permissions: ["produccion_view"] },
      { title: "Colores", url: createPageUrl("Prod_Colores"), icon: Palette, permissions: ["produccion_view"] },
      { title: "Productos Prod.", url: createPageUrl("Prod_Productos"), icon: Shirt, permissions: ["produccion_view"] },
      { title: "Inventario Prod.", url: createPageUrl("Prod_Inventario"), icon: Warehouse, permissions: ["produccion_view"] },
    ]
  },
  {
    title: "Compras Prod.", items: [
      { title: "Proveedores", url: createPageUrl("Prod_Proveedores"), icon: Building2, permissions: ["produccion_view"] },
      { title: "Compras Prod.", url: createPageUrl("Prod_Compras"), icon: ShoppingBag, permissions: ["produccion_view"] },
      { title: "Presupuestos", url: createPageUrl("Prod_Presupuestos"), icon: Calculator, permissions: ["produccion_view"] },
    ]
  },
];

const operariosGroups = [
  {
    title: "Operarios", items: [
      { title: "Dashboard Operarios", url: createPageUrl("Op_Dashboard"), icon: LayoutDashboard, permissions: ["operarios_view"] },
      { title: "Operaciones Diarias", url: createPageUrl("Op_DailyOperations"), icon: Factory, permissions: ["operarios_view"] },
      { title: "Empleados", url: createPageUrl("Op_Employees"), icon: Users, permissions: ["operarios_admin"] },
      { title: "Productos Op.", url: createPageUrl("Op_Products"), icon: Package, permissions: ["operarios_admin"] },
      { title: "Inventario Op.", url: createPageUrl("Op_Inventory"), icon: Warehouse, permissions: ["operarios_admin"] },
    ]
  },
  {
    title: "Entregas", items: [
      { title: "Entregas", url: createPageUrl("Op_Deliveries"), icon: PackageCheck, permissions: ["operarios_view"] },
      { title: "Despachos", url: createPageUrl("Op_Dispatches"), icon: TruckIcon, permissions: ["operarios_view"] },
      { title: "Pendientes", url: createPageUrl("Op_Pending"), icon: Clock, permissions: ["operarios_view"] },
      { title: "Mis Entregas", url: createPageUrl("Op_MyDeliveries"), icon: PackageCheck, permissions: ["operarios_view"] },
    ]
  },
  {
    title: "Pagos Op.", items: [
      { title: "Pagos", url: createPageUrl("Op_Payments"), icon: CreditCard, permissions: ["operarios_admin"] },
      { title: "Transferencias", url: createPageUrl("Op_BankTransfers"), icon: ArrowRightLeft, permissions: ["operarios_admin"] },
      { title: "Cotizador Salario", url: createPageUrl("Op_SalaryQuote"), icon: Calculator, permissions: ["operarios_view"] },
      { title: "Compras Empleados", url: createPageUrl("Op_EmployeePurchases"), icon: ShoppingBag, permissions: ["operarios_view"] },
      { title: "Solicitud de Pago", url: createPageUrl("Op_PaymentRequest"), icon: Receipt, permissions: ["operarios_view"] },
      { title: "Auditoría Op.", url: createPageUrl("Op_AuditLog"), icon: Eye, permissions: ["operarios_admin"] },
    ]
  },
];

const MODULE_ACCESS_PERMS = {
  comercial: ["pos_sales","sales_view","products_view","products_create","inventory_view","purchases_view","expenses_view","reports_basic","customers_view","credits_view","inventory_transfer","accounting_view_transactions","users_view","locations_view","settings_system","agent_access"],
  produccion: ["produccion_view"],
  operarios: ["operarios_view","operarios_admin"],
};

const MODULE_META = {
  comercial: { label: "Comercial", icon: ShoppingCart, badgeCls: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300", activeCls: "bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300", groupCls: "bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300" },
  produccion: { label: "Producción", icon: Factory, badgeCls: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300", activeCls: "bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300", groupCls: "bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300" },
  operarios: { label: "Operarios", icon: Users, badgeCls: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300", activeCls: "bg-violet-100 dark:bg-violet-900/50 text-violet-700 dark:text-violet-300", groupCls: "bg-violet-50 dark:bg-violet-900/30 text-violet-700 dark:text-violet-300" },
};

function LayoutContent({ children }) {
  const location = useLocation();
  const { currentUser, permissions, userRole, isLoading } = useSession();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState({});

  const isAdmin = currentUser?.role === 'admin' || userRole?.name === 'Administrador';

  const hasModuleAccess = (mk) => {
    if (isAdmin) return true;
    return MODULE_ACCESS_PERMS[mk].some(p => permissions?.includes(p));
  };

  const filterItems = (items) => {
    if (isAdmin) return items;
    return items.filter(item => {
      if (!item.permissions || item.permissions.length === 0) return true;
      if (!permissions || permissions.length === 0) return false;
      return item.permissions.some(p => permissions.includes(p));
    });
  };

  const toggleGroup = (key) => setExpandedGroups(prev => ({ ...prev, [key]: !prev[key] }));
  const closeSidebar = () => setSidebarOpen(false);

  const handleLogout = async () => {
    try {
      const { User } = await import("@/entities/User");
      await User.logout();
      window.location.reload();
    } catch (e) { console.error(e); }
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950"><div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" /></div>;
  }

  if (!currentUser) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-4"><div className="bg-white dark:bg-slate-900 p-6 rounded-lg shadow-md text-center max-w-md"><h2 className="text-xl font-semibold text-slate-800 dark:text-slate-100 mb-2">Sesión no iniciada</h2><p className="text-slate-600 dark:text-slate-400">Por favor, inicia sesión para continuar.</p></div></div>;
  }

  const allGroups = [
    ...comercialGroups.map(g => ({ ...g, mk: "comercial" })),
    ...produccionGroups.map(g => ({ ...g, mk: "produccion" })),
    ...operariosGroups.map(g => ({ ...g, mk: "operarios" })),
  ];

  const visibleGroups = allGroups
    .filter(g => hasModuleAccess(g.mk))
    .map(g => ({ ...g, items: filterItems(g.items) }))
    .filter(g => g.items.length > 0);

  const navEntries = [];
  let lastMk = null;
  for (const g of visibleGroups) {
    if (g.mk !== lastMk) { navEntries.push({ type: "header", mk: g.mk }); lastMk = g.mk; }
    navEntries.push({ type: "group", ...g });
  }

  const hideTabBar = location.pathname === createPageUrl("Settings");

  return (
    <div className="min-h-[100dvh] bg-slate-50 dark:bg-slate-950 overflow-x-hidden" style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}>

      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-50">
        <button onClick={() => setSidebarOpen(p => !p)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
          {sidebarOpen ? <X size={24} className="text-slate-900 dark:text-slate-100" /> : <Menu size={24} className="text-slate-900 dark:text-slate-100" />}
        </button>
        <h1 className="text-lg font-semibold text-slate-900 dark:text-slate-100">eQuis-T</h1>
        <ThemeToggle />
      </div>

      {sidebarOpen && <div onClick={closeSidebar} className="fixed inset-0 bg-black/50 z-40 lg:hidden" />}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 bottom-0 w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700 transform transition-transform duration-300 z-50 flex flex-col overflow-y-auto overscroll-none ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>

        <div className="p-5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">eQuis-T</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Sistema Unificado</p>
          </div>
          <div className="hidden lg:block"><ThemeToggle /></div>
        </div>

        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto overscroll-none">
          {navEntries.map((entry, idx) => {
            if (entry.type === "header") {
              const meta = MODULE_META[entry.mk];
              const ModIcon = meta.icon;
              return (
                <div key={`h-${entry.mk}`} className={`flex items-center gap-2 px-2 pb-1 ${idx > 0 ? 'pt-4' : 'pt-1'}`}>
                  <ModIcon size={12} className="text-slate-400" />
                  <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">{meta.label}</span>
                  <div className="flex-1 h-px bg-slate-100 dark:bg-slate-800" />
                </div>
              );
            }
            const meta = MODULE_META[entry.mk];
            const gKey = `${entry.mk}-${entry.title}`;
            const isExpanded = expandedGroups[gKey] ?? entry.items.some(i => location.pathname === i.url);
            const hasActive = entry.items.some(i => location.pathname === i.url);
            return (
              <div key={gKey}>
                <button
                  onClick={() => toggleGroup(gKey)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-colors ${hasActive ? meta.groupCls : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                >
                  <span>{entry.title}</span>
                  <ChevronRight size={14} className={`transition-transform text-slate-400 ${isExpanded ? 'rotate-90' : ''}`} />
                </button>
                {isExpanded && (
                  <div className="ml-3 space-y-0.5 mt-0.5">
                    {entry.items.map(item => {
                      const isActive = location.pathname === item.url;
                      const Icon = item.icon;
                      return (
                        <Link key={item.title} to={item.url} onClick={closeSidebar}
                          className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${isActive ? `${meta.activeCls} font-medium` : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                          <Icon size={15} />
                          <span>{item.title}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
          <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate mb-2">
            {currentUser.full_name || currentUser.email}
          </p>
          <div className="flex flex-wrap gap-1 mb-3">
            {Object.keys(MODULE_META).filter(hasModuleAccess).map(mk => {
              const meta = MODULE_META[mk];
              return <span key={mk} className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${meta.badgeCls}`}>{meta.label}</span>;
            })}
          </div>
          <button onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition-colors">
            <LogOut size={16} />
            Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="lg:ml-72 min-h-[100dvh] pb-24 lg:pb-0 overflow-x-hidden overflow-y-auto touch-pan-y">
        <AnimatePresence mode="wait">
          <motion.div key={location.pathname} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2, ease: "easeInOut" }}>
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {!hideTabBar && <BottomTabBar />}
    </div>
  );
}

export default function Layout({ children }) {
  return (
    <ThemeProvider>
      <SessionProvider>
        <LayoutContent>{children}</LayoutContent>
      </SessionProvider>
    </ThemeProvider>
  );
}
