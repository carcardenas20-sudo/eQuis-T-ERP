import React from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

const CATEGORIES = ["all", "chaquetas_hombre", "chaquetas_mujer", "chaquetas_niños", "accesorios", "materia_prima"];

export default function ProductFilters({ filters, onFilterChange }) {
  const handleFilter = (key, value) => {
    onFilterChange(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-white rounded-xl shadow-md border">
      {/* Search Input */}
      <div className="relative sm:col-span-2 md:col-span-1">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar producto..."
          value={filters.search}
          onChange={e => handleFilter('search', e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Category Filter */}
      <div>
        <Select value={filters.category} onValueChange={value => handleFilter('category', value)}>
          <SelectTrigger>
            <SelectValue placeholder="Categoría" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map(cat => (
              <SelectItem key={cat} value={cat}>
                {cat === 'all' ? 'Todas las Categorías' : cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Status Filter */}
      <div>
        <Select value={filters.status} onValueChange={value => handleFilter('status', value)}>
          <SelectTrigger>
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los Estados</SelectItem>
            <SelectItem value="active">Activo</SelectItem>
            <SelectItem value="inactive">Inactivo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Stock Filter */}
      <div>
        <Select value={filters.stock} onValueChange={value => handleFilter('stock', value)}>
          <SelectTrigger>
            <SelectValue placeholder="Stock" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todo el Stock</SelectItem>
            <SelectItem value="in_stock">En Stock</SelectItem>
            <SelectItem value="out_of_stock">Sin Stock</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}