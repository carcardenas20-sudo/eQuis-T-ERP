
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, Package, EyeOff, Eye, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const getCategoryBadgeColor = (category) => {
    const colors = {
      'chaquetas_hombre': 'bg-blue-100 text-blue-800 border-blue-200',
      'chaquetas_mujer': 'bg-pink-100 text-pink-800 border-pink-200',
      'chaquetas_niños': 'bg-green-100 text-green-800 border-green-200',
      'accesorios': 'bg-purple-100 text-purple-800 border-purple-200',
      'materia_prima': 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return colors[category] || 'bg-gray-100 text-gray-800 border-gray-200';
};

const ProductRow = ({ product, inventory, onEditProduct, onToggleActive, onDeleteProduct }) => {
  const totalStock = inventory
    .filter(inv => inv.product_id === product.sku)
    .reduce((sum, inv) => sum + inv.current_stock, 0);

  return (
    <TableRow className="hover:bg-slate-50">
      <TableCell>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center overflow-hidden">
            {product.image_url ? (
              <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
            ) : (
              <Package className="w-6 h-6 text-gray-400" />
            )}
          </div>
          <div>
            <p className="font-semibold text-slate-900">{product.name}</p>
            <p className="text-xs text-slate-500">SKU: {product.sku}</p>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <Badge variant="outline" className={`${getCategoryBadgeColor(product.category)}`}>
          {product.category?.replace(/_/g, ' ')}
        </Badge>
      </TableCell>
      <TableCell className="text-right font-medium">
        ${product.sale_price?.toLocaleString()}
      </TableCell>
      <TableCell className="text-center">
        <Badge 
          className={
            totalStock > (product.minimum_stock || 5) ? "bg-green-100 text-green-800" :
            totalStock > 0 ? "bg-orange-100 text-orange-800" : "bg-red-100 text-red-800"
          }
        >
          {totalStock}
        </Badge>
      </TableCell>
      <TableCell>
        <Badge variant={product.is_active ? "default" : "destructive"} className={product.is_active ? "bg-emerald-500" : ""}>
          {product.is_active ? "Activo" : "Inactivo"}
        </Badge>
      </TableCell>
      <TableCell className="text-right">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onEditProduct(product)}>
              <Edit className="w-4 h-4 mr-2" />
              Editar
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onToggleActive(product)}>
              {product.is_active ? (
                <>
                  <EyeOff className="w-4 h-4 mr-2" /> Desactivar
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4 mr-2" /> Activar
                </>
              )}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onDeleteProduct(product)} className="text-red-600">
              <Trash2 className="w-4 h-4 mr-2" />
              Eliminar
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </TableCell>
    </TableRow>
  );
};

const LoadingSkeleton = () => (
    Array(8).fill(0).map((_, i) => (
        <TableRow key={i}>
            <TableCell>
                <div className="flex items-center gap-3">
                    <Skeleton className="w-12 h-12 rounded-lg" />
                    <div>
                        <Skeleton className="h-4 w-32 mb-1" />
                        <Skeleton className="h-3 w-20" />
                    </div>
                </div>
            </TableCell>
            <TableCell><Skeleton className="h-6 w-24 rounded-full" /></TableCell>
            <TableCell><Skeleton className="h-4 w-16" /></TableCell>
            <TableCell><Skeleton className="h-6 w-12 rounded-full" /></TableCell>
            <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
            <TableCell><Skeleton className="h-8 w-8 rounded-full" /></TableCell>
        </TableRow>
    ))
);

export default function ProductList({ products, inventory, onEditProduct, onToggleActive, onDeleteProduct, isLoading }) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-slate-50">
            <TableHead>Producto</TableHead>
            <TableHead>Categoría</TableHead>
            <TableHead className="text-right">Precio</TableHead>
            <TableHead className="text-center">Stock</TableHead>
            <TableHead>Estado</TableHead>
            <TableHead className="text-right">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <LoadingSkeleton />
          ) : products.length > 0 ? (
            products.map(product => (
              <ProductRow 
                key={product.id} 
                product={product} 
                inventory={inventory}
                onEditProduct={onEditProduct} 
                onToggleActive={onToggleActive}
                onDeleteProduct={onDeleteProduct}
              />
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-12 text-slate-500">
                <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                No se encontraron productos con los filtros actuales.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
