import React, { useState } from "react";
import { Role } from "@/entities/Role";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Plus, Edit, Trash2, MoreHorizontal, Shield, Loader2, AlertCircle, Users } from "lucide-react";

const ALL_PERMISSIONS = [
  // Punto de Venta
  { 
    id: "pos_sales", 
    label: "Realizar Ventas", 
    category: "Punto de Venta", 
    level: "Básico",
    description: "Permite procesar ventas básicas en el punto de venta"
  },
  { 
    id: "pos_apply_discounts", 
    label: "Aplicar Descuentos", 
    category: "Punto de Venta", 
    level: "Avanzado",
    description: "🚨 CRÍTICO: Permite modificar campos de descuento en el carrito. Sin este permiso, los campos están BLOQUEADOS"
  },
  { 
    id: "pos_cancel_sales", 
    label: "Cancelar Ventas", 
    category: "Punto de Venta", 
    level: "Avanzado",
    description: "Permite cancelar ventas ya procesadas"
  },
  { 
    id: "pos_process_returns", 
    label: "Procesar Devoluciones", 
    category: "Punto de Venta", 
    level: "Avanzado",
    description: "Permite procesar devoluciones de productos"
  },

  // Productos
  { 
    id: "products_view", 
    label: "Ver Productos", 
    category: "Productos", 
    level: "Básico",
    description: "Permite ver el catálogo de productos"
  },
  { 
    id: "products_create", 
    label: "Crear Productos", 
    category: "Productos", 
    level: "Intermedio",
    description: "Permite crear nuevos productos en el sistema"
  },
  { 
    id: "products_edit", 
    label: "Editar Productos", 
    category: "Productos", 
    level: "Intermedio",
    description: "Permite modificar información de productos existentes"
  },

  // Inventario
  { 
    id: "inventory_view", 
    label: "Ver Inventario", 
    category: "Inventario", 
    level: "Básico",
    description: "Permite consultar niveles de stock"
  },
  { 
    id: "inventory_adjust", 
    label: "Ajustar Stock", 
    category: "Inventario", 
    level: "Intermedio",
    description: "Permite corregir cantidades de inventario"
  },
  { 
    id: "inventory_transfer", 
    label: "Transferir Stock", 
    category: "Inventario", 
    level: "Avanzado",
    description: "Permite trasladar stock entre sucursales"
  },

  // Clientes
  { 
    id: "customers_view", 
    label: "Ver Clientes", 
    category: "Clientes", 
    level: "Básico",
    description: "Permite consultar información de clientes"
  },
  { 
    id: "customers_create", 
    label: "Crear Clientes", 
    category: "Clientes", 
    level: "Básico",
    description: "Permite registrar nuevos clientes"
  },
  { 
    id: "customers_edit", 
    label: "Editar Clientes", 
    category: "Clientes", 
    level: "Intermedio",
    description: "Permite modificar información de clientes"
  },

  // Créditos
  { 
    id: "credits_view", 
    label: "Ver Créditos", 
    category: "Créditos", 
    level: "Básico",
    description: "Permite consultar créditos pendientes"
  },
  { 
    id: "credits_create", 
    label: "Otorgar Créditos", 
    category: "Créditos", 
    level: "Intermedio",
    description: "Permite crear ventas a crédito"
  },
  { 
    id: "credits_collect", 
    label: "Cobrar Créditos", 
    category: "Créditos", 
    level: "Básico",
    description: "Permite registrar pagos de créditos"
  },

  // Ventas
  { 
    id: "sales_view", 
    label: "Ver Ventas", 
    category: "Ventas", 
    level: "Básico",
    description: "Permite consultar historial de ventas"
  },
  { 
    id: "sales_print", 
    label: "Reimprimir Facturas", 
    category: "Ventas", 
    level: "Básico",
    description: "Permite reimprimir facturas existentes"
  },

  // Gastos
  { 
    id: "expenses_view", 
    label: "Ver Gastos", 
    category: "Gastos", 
    level: "Básico",
    description: "Permite consultar gastos registrados"
  },
  { 
    id: "expenses_create", 
    label: "Registrar Gastos", 
    category: "Gastos", 
    level: "Intermedio",
    description: "Permite registrar nuevos gastos"
  },

  // Reportes
  { 
    id: "reports_basic", 
    label: "Reportes Básicos", 
    category: "Reportes", 
    level: "Básico",
    description: "Permite ver reportes de ventas básicos"
  },
  { 
    id: "reports_advanced", 
    label: "Reportes Avanzados", 
    category: "Reportes", 
    level: "Intermedio",
    description: "Permite ver reportes detallados y análisis"
  },

  // Compras
  { 
    id: "purchases_view", 
    label: "Ver Compras", 
    category: "Compras", 
    level: "Básico",
    description: "Permite consultar órdenes de compra"
  },
  { 
    id: "purchases_create", 
    label: "Crear Compras", 
    category: "Compras", 
    level: "Intermedio",
    description: "Permite crear nuevas órdenes de compra"
  },

  // Contabilidad
  { 
    id: "accounting_view_transactions", 
    label: "Ver Transacciones", 
    category: "Contabilidad", 
    level: "Intermedio",
    description: "Permite ver movimientos bancarios"
  },

  // Sistema
  { 
    id: "agent_access", 
    label: "Acceder al Asistente IA", 
    category: "Sistema", 
    level: "Gerencial",
    description: "Permite usar el asistente de IA"
  },
  { 
    id: "users_view", 
    label: "Ver Usuarios", 
    category: "Sistema", 
    level: "Gerencial",
    description: "Permite ver información de usuarios"
  },
  { 
    id: "locations_view", 
    label: "Ver Sucursales", 
    category: "Sistema", 
    level: "Básico",
    description: "Permite ver información de sucursales"
  },
  { 
    id: "settings_system", 
    label: "Configuración del Sistema", 
    category: "Sistema", 
    level: "Administrador",
    description: "Permite modificar configuraciones generales"
  }
];

const levelColors = {
  "Básico": "bg-green-100 text-green-800",
  "Intermedio": "bg-yellow-100 text-yellow-800", 
  "Avanzado": "bg-orange-100 text-orange-800",
  "Gerencial": "bg-blue-100 text-blue-800",
  "Administrador": "bg-red-100 text-red-800"
};

// Predefined role templates
const PREDEFINED_ROLES = [
  {
    name: "Vendedor Básico",
    description: "Solo puede realizar ventas básicas SIN descuentos",
    permissions: ["pos_sales", "customers_create", "customers_view", "sales_view", "sales_print", "products_view"]
  },
  {
    name: "Líder de Punto",  
    description: "Vendedor básico SIN permisos de descuento - perfil estándar para líderes de punto",
    permissions: ["pos_sales", "customers_create", "customers_view", "customers_edit", "sales_view", "sales_print", "credits_view", "credits_collect", "products_view", "inventory_view", "reports_basic"]
  },
  {
    name: "Cajero Senior",
    description: "Vendedor CON permisos de descuentos y devoluciones",
    permissions: ["pos_sales", "pos_apply_discounts", "pos_process_returns", "customers_create", "customers_view", "customers_edit", "sales_view", "sales_print", "credits_view", "credits_create", "credits_collect", "products_view"]
  },
  {
    name: "Supervisor",
    description: "Supervisión completa con todos los permisos de venta y reportes",
    permissions: [
      "pos_sales", "pos_apply_discounts", "pos_process_returns", "pos_cancel_sales",
      "products_view", "products_create", "products_edit", "inventory_view", "inventory_adjust",
      "customers_view", "customers_create", "customers_edit",
      "sales_view", "sales_print", "credits_view", "credits_create", "credits_collect",
      "expenses_view", "expenses_create", "reports_basic", "reports_advanced"
    ]
  }
];

const RoleForm = ({ role, onSave, onCancel, isSaving }) => {
  const [formData, setFormData] = useState(role || { name: "", description: "", permissions: [] });
  const [error, setError] = useState("");

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePermissionChange = (permissionId, checked) => {
    const currentPermissions = formData.permissions || [];
    let newPermissions;
    if (checked) {
      newPermissions = [...currentPermissions, permissionId];
    } else {
      newPermissions = currentPermissions.filter(p => p !== permissionId);
    }
    handleChange('permissions', newPermissions);
  };

  const applyPredefinedRole = (predefinedRole) => {
    setFormData(prev => ({
      ...prev,
      name: predefinedRole.name,
      description: predefinedRole.description,
      permissions: [...predefinedRole.permissions]
    }));
  };

  const handleSubmit = async () => {
    if (!formData.name) {
      setError("El nombre del rol es obligatorio.");
      return;
    }
    setError("");
    await onSave(formData);
  };

  // Group permissions by category
  const groupedPermissions = ALL_PERMISSIONS.reduce((groups, permission) => {
    const category = permission.category;
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(permission);
    return groups;
  }, {});

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            {role ? 'Editar Rol' : 'Nuevo Rol'}
          </DialogTitle>
          <DialogDescription>
            Define permisos específicos. Especial atención al permiso de "Aplicar Descuentos".
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Predefined Role Templates */}
          {!role && (
            <div className="border-b pb-4">
              <Label className="text-base font-semibold mb-3 block">Plantillas de Roles Recomendadas</Label>
              <p className="text-sm text-slate-600 mb-4">
                Usa estas plantillas. Nota: "Líder de Punto" NO tiene permisos de descuento.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {PREDEFINED_ROLES.map((predefined, index) => (
                  <Card 
                    key={index} 
                    className={`cursor-pointer hover:bg-blue-50 transition-colors ${
                      predefined.name === "Líder de Punto" ? "border-2 border-orange-300 bg-orange-50" : ""
                    }`} 
                    onClick={() => applyPredefinedRole(predefined)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-blue-600" />
                        <h4 className="font-medium text-sm">{predefined.name}</h4>
                        {predefined.name === "Líder de Punto" && (
                          <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded">SIN DESCUENTOS</span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600">{predefined.description}</p>
                      <div className="text-xs text-blue-600 mt-2">{predefined.permissions.length} permisos</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre del Rol *</Label>
              <Input 
                id="name" 
                value={formData.name} 
                onChange={e => handleChange('name', e.target.value)}
                placeholder="Ej: Líder de Punto" 
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">Descripción</Label>
            <Textarea 
              id="description" 
              value={formData.description} 
              onChange={e => handleChange('description', e.target.value)}
              placeholder="Describe las responsabilidades de este rol..."
            />
          </div>

          <div>
            <Label className="text-lg font-semibold">Permisos del Sistema</Label>
            <p className="text-sm text-slate-600 mb-4">
              Cada permiso controla una funcionalidad específica. Revisa especialmente "Aplicar Descuentos".
            </p>
            
            <div className="space-y-6">
              {Object.entries(groupedPermissions).map(([category, permissions]) => (
                <div key={category} className="border rounded-lg p-4 bg-slate-50">
                  <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                    {category}
                    <span className="text-xs text-slate-500">
                      ({permissions.length} permisos)
                    </span>
                  </h4>
                  
                  <div className="space-y-3">
                    {permissions.map(permission => (
                      <div 
                        key={permission.id} 
                        className={`flex items-start space-x-3 p-4 bg-white rounded-lg border hover:shadow-sm transition-shadow ${
                          permission.id === 'pos_apply_discounts' ? 'border-2 border-red-300 bg-red-50' : ''
                        }`}
                      >
                        <Checkbox
                          id={permission.id}
                          checked={formData.permissions?.includes(permission.id)}
                          onCheckedChange={checked => handlePermissionChange(permission.id, checked)}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <label 
                            htmlFor={permission.id} 
                            className="text-sm font-medium text-slate-900 cursor-pointer block"
                          >
                            {permission.label}
                            {permission.id === 'pos_apply_discounts' && (
                              <span className="ml-2 text-red-600 font-bold">⚠️ DESCUENTOS</span>
                            )}
                          </label>
                          <p className="text-xs text-slate-600 mt-1">{permission.description}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className={`text-xs px-2 py-0.5 rounded-full ${levelColors[permission.level]}`}>
                              {permission.level}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel} disabled={isSaving}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} disabled={isSaving}>
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Guardar Rol'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default function RoleManager({ roles = [], onRefresh, isLoading }) {
  const [showForm, setShowForm] = useState(false);
  const [editingRole, setEditingRole] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async (data) => {
    setIsSaving(true);
    try {
      if (editingRole) {
        await Role.update(editingRole.id, data);
      } else {
        await Role.create(data);
      }
      setShowForm(false);
      setEditingRole(null);
      onRefresh();
    } catch (error) {
      console.error("Error saving role:", error);
    }
    setIsSaving(false);
  };

  const handleDelete = async (role) => {
    if (window.confirm(`¿Estás seguro de eliminar el rol "${role.name}"?`)) {
      try {
        await Role.delete(role.id);
        onRefresh();
      } catch (error) {
        console.error("Error deleting role:", error);
        alert("Error: No se puede eliminar el rol si hay usuarios asignados a él.");
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">Roles de Usuario</h2>
          <p className="text-slate-600 text-sm mt-1">
            Control granular de permisos. Especial atención al permiso "pos_apply_discounts".
          </p>
        </div>
        <Button 
          onClick={() => { setEditingRole(null); setShowForm(true); }} 
          className="gap-2"
        >
          <Plus className="w-4 h-4" /> 
          Nuevo Rol
        </Button>
      </div>

      <Card className="shadow-lg border-0">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50">
                <TableHead>Rol</TableHead>
                <TableHead>Permisos Críticos</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-12">
                    <Loader2 className="w-8 h-8 mx-auto animate-spin text-blue-600" />
                  </TableCell>
                </TableRow>
              ) : roles && roles.length > 0 ? (
                roles.map((role) => (
                  <TableRow key={role.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium text-slate-900">{role.name}</div>
                        <div className="text-sm text-slate-500">{role.description}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-2 max-w-md">
                        <span className="text-sm font-medium text-slate-700">
                          {role.permissions?.length || 0} permisos total
                        </span>
                        <div className="w-full">
                          {role.permissions?.includes('pos_apply_discounts') ? (
                            <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded border border-red-300 font-bold">
                              ⚠️ PUEDE APLICAR DESCUENTOS
                            </span>
                          ) : (
                            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded border border-green-300">
                              ✅ SIN PERMISOS DE DESCUENTO
                            </span>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem 
                            onClick={() => { setEditingRole(role); setShowForm(true); }}
                          >
                            <Edit className="w-4 h-4 mr-2" /> 
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => handleDelete(role)} 
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" /> 
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={3} className="text-center py-12 text-slate-500">
                    <Shield className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    No hay roles configurados
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {showForm && (
        <RoleForm
          role={editingRole}
          onSave={handleSave}
          onCancel={() => { setShowForm(false); setEditingRole(null); }}
          isSaving={isSaving}
        />
      )}
    </div>
  );
}