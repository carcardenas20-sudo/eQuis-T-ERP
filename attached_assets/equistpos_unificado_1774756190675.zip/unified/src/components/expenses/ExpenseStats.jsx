import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingDown, Receipt, Calendar } from "lucide-react";

export default function ExpenseStats({ expenses }) {
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const averageExpense = expenses.length > 0 ? totalExpenses / expenses.length : 0;

  // Calculate category breakdown
  const categoryTotals = expenses.reduce((acc, expense) => {
    acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
    return acc;
  }, {});

  const topCategory = Object.entries(categoryTotals)
    .sort(([,a], [,b]) => b - a)[0];

  const categoryLabels = {
    servicios_publicos: "Servicios Públicos",
    alquiler: "Alquiler",
    suministros: "Suministros", 
    marketing: "Marketing",
    transporte: "Transporte",
    alimentacion: "Alimentación",
    mantenimiento: "Mantenimiento",
    salarios: "Salarios",
    impuestos: "Impuestos",
    seguros: "Seguros",
    telecomunicaciones: "Telecomunicaciones",
    otros: "Otros"
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">
            Total Gastos
          </CardTitle>
          <TrendingDown className="w-5 h-5 text-red-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">
            ${totalExpenses.toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {expenses.length} transacciones
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">
            Promedio por Gasto
          </CardTitle>
          <DollarSign className="w-5 h-5 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-slate-900">
            ${averageExpense.toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Promedio del período
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">
            Número de Gastos
          </CardTitle>
          <Receipt className="w-5 h-5 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-slate-900">
            {expenses.length}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Gastos registrados
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-lg border-0 hover:shadow-xl transition-shadow">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-slate-600">
            Categoría Principal
          </CardTitle>
          <Calendar className="w-5 h-5 text-purple-500" />
        </CardHeader>
        <CardContent>
          <div className="text-lg font-bold text-slate-900">
            {topCategory ? categoryLabels[topCategory[0]] || topCategory[0] : 'N/A'}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {topCategory ? `$${topCategory[1].toLocaleString()}` : 'Sin gastos'}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}