
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Loader2, AlertTriangle, Shield, CheckCircle2 } from "lucide-react";
import { Role } from "@/entities/Role";

export default function UserForm({ user, locations, onSave, onCancel, isSaving }) {
  const [formData, setFormData] = useState(user || {});
  const [roles, setRoles] = useState([]);
  const [selectedRole, setSelectedRole] = useState(null);

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const rolesData = await Role.list();
        console.log("📋 Roles disponibles para asignar:", rolesData.map(r => ({ id: r.id, name: r.name })));
        setRoles(rolesData);
        
        // Find current user's role
        if (user?.role_id) {
          const currentRole = rolesData.find(r => r.id === user.role_id);
          console.log("🔍 Rol actual del usuario:", user.role_id, "Encontrado:", currentRole?.name || "NO ENCONTRADO");
          setSelectedRole(currentRole);
        }
      } catch (error) {
        console.error("Error loading roles:", error);
      }
    };
    fetchRoles();
    setFormData(user);
  }, [user]);

  const handleChange = (field, value) => {
    console.log(`✏️ Cambiando ${field}:`, value);
    setFormData(p => ({ ...p, [field]: value }));
  };

  const handleRoleChange = (roleId) => {
    console.log("🔄 Cambiando rol a:", roleId);
    handleChange('role_id', roleId);
    const role = roles.find(r => r.id === roleId);
    console.log("🔄 Rol seleccionado:", role?.name);
    setSelectedRole(role);
  };

  // Check if user has invalid role_id
  const hasInvalidRole = user?.role_id && !roles.find(r => r.id === user.role_id);
  const hasNoRole = !user?.role_id || user.role_id === '';

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            Editar Usuario: {user.full_name}
          </DialogTitle>
          <DialogDescription>
            Modifica la información, rol y permisos del usuario.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Warning for invalid or missing role */}
          {(hasInvalidRole || hasNoRole) && (
            <Alert variant="destructive" className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-red-800">
                {hasInvalidRole && (
                  <div>
                    <strong>⚠️ Rol Inválido Detectado:</strong>
                    <br />
                    <span className="text-sm font-mono bg-red-100 px-2 py-1 rounded mt-1 inline-block">
                      role_id actual: {user.role_id}
                    </span>
                    <br />
                    <span className="text-sm mt-2 block">
                      Este rol no existe en el sistema. Selecciona un rol válido abajo para corregirlo.
                    </span>
                  </div>
                )}
                {hasNoRole && !hasInvalidRole && (
                  <div>
                    <strong>⚠️ Sin Rol:</strong> Este usuario no tiene un rol asignado.
                    <br />
                    <span className="text-sm">Debe seleccionar un rol para que el usuario tenga permisos.</span>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}

          {/* User Basic Info */}
          <div className="bg-slate-50 p-4 rounded-lg border">
            <h3 className="font-semibold text-slate-700 mb-3">Información del Usuario</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-slate-500">Nombre Completo</Label>
                <Input value={formData.full_name || ''} disabled className="bg-white" />
              </div>
              <div>
                <Label className="text-xs text-slate-500">Email</Label>
                <Input value={formData.email || ''} disabled className="bg-white" />
              </div>
            </div>
          </div>

          {/* Role Selection - DESTACADO */}
          <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-blue-600" />
              <h3 className="font-semibold text-blue-900">Asignación de Rol * (REQUERIDO)</h3>
            </div>
            
            <div className="space-y-3">
              <Select 
                value={formData.role_id || ''} 
                onValueChange={handleRoleChange}
              >
                <SelectTrigger className="w-full h-12 bg-white border-2 border-blue-300">
                  <SelectValue placeholder="⚠️ Seleccionar rol..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(role => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2 py-1">
                        <Shield className="w-4 h-4 text-blue-600" />
                        <span className="font-medium">{role.name}</span>
                        <Badge variant="outline" className="ml-2 text-xs">
                          {role.permissions?.length || 0} permisos
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Preview of selected role permissions */}
              {selectedRole && selectedRole.permissions && selectedRole.permissions.length > 0 && (
                <div className="bg-white p-3 rounded border">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <span className="text-sm font-medium text-slate-700">
                      Permisos de "{selectedRole.name}":
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {selectedRole.permissions.slice(0, 10).map((perm, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {perm.replace(/_/g, ' ')}
                      </Badge>
                    ))}
                    {selectedRole.permissions.length > 10 && (
                      <Badge variant="outline" className="text-xs">
                        +{selectedRole.permissions.length - 10} más
                      </Badge>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Contact & Employment Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Teléfono</Label>
              <Input 
                id="phone" 
                value={formData.phone || ''} 
                onChange={e => handleChange('phone', e.target.value)}
                placeholder="+57 300 123 4567"
              />
            </div>
            <div>
              <Label htmlFor="employee_id">ID de Empleado</Label>
              <Input 
                id="employee_id" 
                value={formData.employee_id || ''} 
                onChange={e => handleChange('employee_id', e.target.value)}
                placeholder="EMP-001"
              />
            </div>
          </div>

          {/* Location Assignment */}
          <div>
            <Label htmlFor="location_id">Sucursal Asignada</Label>
            <Select 
              value={formData.location_id || ''} 
              onValueChange={value => handleChange('location_id', value)}
            >
              <SelectTrigger id="location_id" className="w-full">
                <SelectValue placeholder="Seleccionar sucursal..." />
              </SelectTrigger>
              <SelectContent>
                {locations.map(loc => (
                  <SelectItem key={loc.id} value={loc.id}>
                    {loc.name}
                    {loc.is_main && <Badge variant="outline" className="ml-2 text-xs">Principal</Badge>}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Salary */}
          <div>
            <Label htmlFor="salary">Salario</Label>
            <Input 
              type="number" 
              id="salary" 
              value={formData.salary || ''} 
              onChange={e => handleChange('salary', parseFloat(e.target.value) || 0)}
              placeholder="0"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel} disabled={isSaving}>
            Cancelar
          </Button>
          <Button 
            onClick={() => {
              console.log("💾 Intentando guardar con formData:", formData);
              onSave(formData);
            }} 
            disabled={isSaving || !formData.role_id}
            className="gap-2"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Guardar Cambios
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
