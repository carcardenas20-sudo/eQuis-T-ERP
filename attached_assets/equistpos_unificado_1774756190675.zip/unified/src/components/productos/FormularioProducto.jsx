import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { X, Plus, Trash2, Shirt, Package, Palette, Copy } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import GestorCombinacionesPredefinidas from './GestorCombinacionesPredefinidas';

export default function FormularioProducto({ producto, materiasPrimas, colores = [], onSubmit, onCancel }) {
  const DRAFT_KEY = `producto_draft_${producto?.id || 'nuevo'}`;

  const [formData, setFormData] = useState(() => {
    // Intentar recuperar borrador guardado
    try {
      const draft = localStorage.getItem(DRAFT_KEY);
      if (draft) {
        const parsed = JSON.parse(draft);
        // Solo restaurar si el borrador es más reciente que hace 24h
        if (parsed._savedAt && Date.now() - parsed._savedAt < 24 * 60 * 60 * 1000) {
          const { _savedAt, ...data } = parsed;
          return data;
        }
      }
    } catch (_) {}

    return producto ? {
      ...producto,
      materiales_requeridos: producto.materiales_requeridos || [],
      combinaciones_predefinidas: producto.combinaciones_predefinidas || []
    } : {
      nombre: "",
      descripcion: "",
      tipo_diseno: "por_secciones",
      tallas: [],
      materiales_requeridos: [],
      combinaciones_predefinidas: [],
      costo_mano_obra: 0,
      tiempo_fabricacion_horas: 0,
      imagen_url: ""
    };
  });

  const [hasDraft, setHasDraft] = useState(() => {
    try {
      const draft = localStorage.getItem(`producto_draft_${producto?.id || 'nuevo'}`);
      if (!draft) return false;
      const parsed = JSON.parse(draft);
      return !!(parsed._savedAt && Date.now() - parsed._savedAt < 24 * 60 * 60 * 1000);
    } catch (_) { return false; }
  });

  const isFirstRender = useRef(true);

  // Auto-guardar en localStorage con debounce (evita escrituras excesivas)
  useEffect(() => {
    if (isFirstRender.current) { isFirstRender.current = false; return; }
    const timer = setTimeout(() => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify({ ...formData, _savedAt: Date.now() }));
      } catch (_) {}
    }, 800);
    return () => clearTimeout(timer);
  }, [formData]);

  const [tallaInput, setTallaInput] = useState("");

  const costoTotalMateriales = useMemo(() => {
    return (formData.materiales_requeridos || []).reduce((total, material) => {
      const mp = materiasPrimas.find(m => m.id === material.materia_prima_id);
      return total + (mp?.precio_por_unidad || 0) * (material.cantidad_por_unidad || 0);
    }, 0);
  }, [formData.materiales_requeridos, materiasPrimas]);

  const agregarTalla = () => {
    if (tallaInput.trim() && !formData.tallas.includes(tallaInput.trim())) {
      setFormData({ ...formData, tallas: [...formData.tallas, tallaInput.trim()] });
      setTallaInput("");
    }
  };

  const removerTalla = (talla) => {
    setFormData({ ...formData, tallas: formData.tallas.filter(t => t !== talla) });
  };

  const agregarMaterial = () => {
    const nuevoMaterial = {
      row_id: `row_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      materia_prima_id: "",
      seccion: "superior",
      cantidad_por_unidad: 0,
      piezas_por_unidad: 1,
      etiqueta_cantidad: "",
      nombre_seccion_display: "",
      es_opcional: false
    };
    setFormData({ ...formData, materiales_requeridos: [...formData.materiales_requeridos, nuevoMaterial] });
  };

  const removerMaterial = (index) => {
    setFormData(prev => ({
      ...prev,
      materiales_requeridos: prev.materiales_requeridos.filter((_, i) => i !== index)
    }));
  };

  const actualizarMaterial = (index, campo, valor) => {
    setFormData(prev => ({
      ...prev,
      materiales_requeridos: prev.materiales_requeridos.map((m, i) => i === index ? { ...m, [campo]: valor } : m)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.nombre.trim()) { alert("El nombre del producto es obligatorio."); return; }
    if (formData.tallas.length === 0) { alert("Debe agregar al menos una talla."); return; }
    // Limpiar borrador al guardar exitosamente
    try { localStorage.removeItem(DRAFT_KEY); } catch (_) {}
    onSubmit(formData);
  };

  const descartarBorrador = () => {
    try { localStorage.removeItem(DRAFT_KEY); } catch (_) {}
    setHasDraft(false);
    // Restaurar datos originales
    setFormData(producto ? {
      ...producto,
      materiales_requeridos: producto.materiales_requeridos || [],
      combinaciones_predefinidas: producto.combinaciones_predefinidas || []
    } : {
      nombre: "", descripcion: "", tipo_diseno: "por_secciones", tallas: [],
      materiales_requeridos: [], combinaciones_predefinidas: [],
      costo_mano_obra: 0, tiempo_fabricacion_horas: 0, imagen_url: ""
    });
  };

  const esCopia = producto && !producto.id && producto.nombre?.includes(' - Copia');

  const SECCIONES = formData.tipo_diseno === 'fondo_entero'
    ? [{ key: 'fondo_entero', label: 'Fondo Entero' }, { key: 'forro', label: 'Forro' }, { key: 'contraste', label: 'Contraste' }, { key: 'color_propio', label: 'Color Propio' }]
    : [{ key: 'superior', label: 'Superior' }, { key: 'central', label: 'Central' }, { key: 'inferior', label: 'Inferior' }, { key: 'forro', label: 'Forro' }, { key: 'contraste', label: 'Contraste' }, { key: 'color_propio', label: 'Color Propio' }];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-5xl max-h-[90vh] overflow-y-auto"
      >
        <Card className="bg-white shadow-2xl border-slate-200">
          <CardHeader className="border-b border-slate-100 bg-gradient-to-r from-indigo-50 to-purple-50">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl font-bold text-slate-900">
                  {producto?.id ? 'Editar Producto' : 'Nuevo Producto'}
                </CardTitle>
                {esCopia && (
                  <p className="text-sm text-indigo-600 mt-1 flex items-center gap-2">
                    <Copy className="w-4 h-4" />
                    Copiado desde producto original
                  </p>
                )}
                {hasDraft && (
                  <div className="flex items-center gap-2 mt-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-700">
                    <span>⚠️ Se recuperó un borrador guardado automáticamente.</span>
                    <button type="button" onClick={descartarBorrador}
                      className="underline text-amber-600 hover:text-amber-800 shrink-0">
                      Descartar y usar datos originales
                    </button>
                  </div>
                )}
              </div>
              <Button variant="ghost" size="icon" onClick={onCancel}>
                <X className="w-5 h-5" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-4 sm:p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <Tabs defaultValue="info" className="space-y-4">
                <TabsList className="grid grid-cols-3 w-full">
                  <TabsTrigger value="info" className="text-xs sm:text-sm">
                    <Shirt className="w-3 h-3 mr-1" /> Info
                  </TabsTrigger>
                  <TabsTrigger value="materiales" className="text-xs sm:text-sm">
                    <Package className="w-3 h-3 mr-1" /> Materiales
                    {formData.materiales_requeridos.length > 0 && (
                      <Badge className="ml-1 text-xs bg-purple-100 text-purple-700 hidden sm:inline-flex">{formData.materiales_requeridos.length}</Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="combinaciones" className="text-xs sm:text-sm">
                    <Palette className="w-3 h-3 mr-1" /> Combinaciones
                    {(formData.combinaciones_predefinidas || []).length > 0 && (
                      <Badge className="ml-1 text-xs bg-indigo-100 text-indigo-700 hidden sm:inline-flex">{formData.combinaciones_predefinidas.length}</Badge>
                    )}
                  </TabsTrigger>
                </TabsList>

                {/* TAB: INFO */}
                <TabsContent value="info" className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Shirt className="w-5 h-5 text-indigo-600" />
                      <h3 className="text-base font-semibold text-slate-900">Detalles del Producto</h3>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nombre">Nombre del Producto *</Label>
                      <Input
                        id="nombre"
                        value={formData.nombre}
                        onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                        placeholder="Ej: Chaqueta Bomber Clásica"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="descripcion">Descripción</Label>
                      <Textarea
                        id="descripcion"
                        value={formData.descripcion}
                        onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                        placeholder="Breve descripción del diseño..."
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Tipo de Diseño *</Label>
                      <Select value={formData.tipo_diseno} onValueChange={(v) => setFormData({ ...formData, tipo_diseno: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fondo_entero">Fondo Entero</SelectItem>
                          <SelectItem value="por_secciones">Por Secciones</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Tallas Disponibles *</Label>
                      <div className="flex gap-2">
                        <Input
                          value={tallaInput}
                          onChange={(e) => setTallaInput(e.target.value.toUpperCase())}
                          placeholder="Ej: S, M, L"
                        />
                        <Button type="button" variant="outline" onClick={agregarTalla}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {formData.tallas.map(talla => (
                          <Badge key={talla} className="flex items-center gap-1 bg-indigo-100 text-indigo-800">
                            {talla}
                            <button type="button" onClick={() => removerTalla(talla)} className="ml-1 text-indigo-500 hover:text-indigo-700">
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200">
                      <div className="space-y-2">
                        <Label>Costo Mano de Obra</Label>
                        <Input
                          type="number"
                          value={formData.costo_mano_obra}
                          onChange={(e) => setFormData({ ...formData, costo_mano_obra: parseFloat(e.target.value) || 0 })}
                          placeholder="0.00"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Tiempo (Horas)</Label>
                        <Input
                          type="number"
                          value={formData.tiempo_fabricacion_horas}
                          onChange={(e) => setFormData({ ...formData, tiempo_fabricacion_horas: parseFloat(e.target.value) || 0 })}
                          placeholder="0"
                        />
                      </div>
                    </div>

                    <div className="space-y-2 p-3 bg-slate-50 rounded-lg text-sm">
                      <div className="flex justify-between"><span className="text-slate-500">Costo Materiales:</span><span className="font-semibold">${costoTotalMateriales.toFixed(2)}</span></div>
                      <div className="flex justify-between"><span className="text-slate-500">Mano de Obra:</span><span className="font-semibold">${(formData.costo_mano_obra || 0).toFixed(2)}</span></div>
                      <div className="flex justify-between font-bold text-indigo-600 border-t pt-2">
                        <span>Total:</span><span>${(costoTotalMateriales + (formData.costo_mano_obra || 0)).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                {/* TAB: MATERIALES */}
                <TabsContent value="materiales" className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-purple-600" />
                      <h3 className="text-base font-semibold text-slate-900">Materiales Requeridos</h3>
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={agregarMaterial}
                      className="text-purple-600 border-purple-200 hover:bg-purple-50 text-xs">
                      <Plus className="w-3 h-3 mr-1" /> Agregar
                    </Button>
                  </div>

                  <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1">
                    {formData.materiales_requeridos.length === 0 ? (
                      <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-sm">
                        No hay materiales agregados.
                      </div>
                    ) : (
                      formData.materiales_requeridos.map((material, index) => {
                        const mp = materiasPrimas.find(m => m.id === material.materia_prima_id);
                        const costo = (mp?.precio_por_unidad || 0) * (material.cantidad_por_unidad || 0);
                        return (
                          <div key={material.row_id || index} className="border border-slate-200 rounded-lg bg-slate-50 p-3 space-y-2">
                            {/* Fila 1: Material + Sección + Cantidad */}
                            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 items-end">
                              <div className="sm:col-span-2">
                                <Label className="text-xs text-slate-500">Material</Label>
                                <Select value={material.materia_prima_id}
                                  onValueChange={(v) => actualizarMaterial(index, 'materia_prima_id', v)}>
                                  <SelectTrigger className="h-8 text-xs mt-1">
                                    <SelectValue placeholder="Seleccionar" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {materiasPrimas.map(mp => (
                                      <SelectItem key={mp.id} value={mp.id}>{mp.nombre}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label className="text-xs text-slate-500">Sección / Anclaje</Label>
                                <Select value={material.seccion || 'superior'}
                                  onValueChange={(v) => actualizarMaterial(index, 'seccion', v)}>
                                  <SelectTrigger className="h-8 text-xs mt-1">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {SECCIONES.map(s => (
                                      <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="flex items-end gap-2">
                                <div className="flex-1">
                                  <Label className="text-xs text-slate-500">Cant/ud</Label>
                                  <Input type="number" step="0.01"
                                    value={material.cantidad_por_unidad}
                                    onChange={(e) => actualizarMaterial(index, 'cantidad_por_unidad', e.target.value)}
                                    className="h-8 text-xs mt-1" />
                                </div>
                                <div className="text-xs text-slate-500 pb-1">${costo.toFixed(2)}</div>
                                <Button type="button" variant="ghost" size="icon"
                                  onClick={() => removerMaterial(index)}
                                  className="text-red-400 hover:bg-red-50 h-8 w-8 shrink-0">
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            {/* Fila 2: Campos para remisión individual */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-200">
                              <div>
                                <Label className="text-xs text-slate-400">Nombre en remisión</Label>
                                <Input
                                  placeholder="Ej: BOLSILLO, MANGA"
                                  value={material.nombre_seccion_display || ""}
                                  onChange={(e) => actualizarMaterial(index, 'nombre_seccion_display', e.target.value)}
                                  className="h-7 text-xs mt-0.5" />
                              </div>
                              <div>
                                <Label className="text-xs text-slate-400">Piezas x prenda</Label>
                                <Input
                                  type="number" min="1" step="1"
                                  placeholder="1"
                                  value={material.piezas_por_unidad || 1}
                                  onChange={(e) => actualizarMaterial(index, 'piezas_por_unidad', parseFloat(e.target.value) || 1)}
                                  className="h-7 text-xs mt-0.5" />
                              </div>
                              <div>
                                <Label className="text-xs text-slate-400">Unidad en remisión</Label>
                                <Input
                                  placeholder="Ej: tiras, pares, unidades"
                                  value={material.unidad_remision || material.etiqueta_cantidad || ""}
                                  onChange={(e) => actualizarMaterial(index, 'unidad_remision', e.target.value)}
                                  className="h-7 text-xs mt-0.5" />
                              </div>
                              <div>
                                <Label className="text-xs text-slate-400">Descripción en remisión</Label>
                                <Input
                                  placeholder="Ej: tiras tejidas negras"
                                  value={material.descripcion_remision || ""}
                                  onChange={(e) => actualizarMaterial(index, 'descripcion_remision', e.target.value)}
                                  className="h-7 text-xs mt-0.5" />
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                  <p className="text-xs text-slate-400">💡 La sección/anclaje define qué color toma este material en cada combinación.</p>
                </TabsContent>

                {/* TAB: COMBINACIONES */}
                <TabsContent value="combinaciones" className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Palette className="w-5 h-5 text-indigo-600" />
                    <h3 className="text-base font-semibold text-slate-900">Combinaciones Predefinidas</h3>
                  </div>
                  <p className="text-xs text-slate-500">
                    Define las combinaciones de colores típicas de este producto. Al presupuestar, simplemente las seleccionas y pones cantidades por talla.
                  </p>
                  <GestorCombinacionesPredefinidas
                    formData={formData}
                    setFormData={setFormData}
                    materiasPrimas={materiasPrimas}
                    colores={colores}
                  />
                </TabsContent>
              </Tabs>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <Button type="button" variant="outline" onClick={onCancel}>Cancelar</Button>
                <Button type="submit"
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8">
                  {producto?.id ? 'Actualizar' : 'Crear'} Producto
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}