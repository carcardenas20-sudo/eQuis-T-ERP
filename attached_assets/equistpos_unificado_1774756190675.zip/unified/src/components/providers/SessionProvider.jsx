import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/entities/User';
import { Role } from '@/entities/Role';
import { Location } from '@/entities/Location';

const SessionContext = createContext(null);

export function SessionProvider({ children }) {
  const [state, setState] = useState({
    currentUser: null,
    userRole: null,
    userLocation: null,
    permissions: [],
    isLoading: true,
    error: null
  });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        console.log("🔐 SessionProvider: ========== INICIO ==========");
        const user = await User.me();
        if (cancelled) return;

        console.log("🔐 SessionProvider: Usuario cargado:");
        console.log("   - Email:", user.email);
        console.log("   - Role (legacy):", user.role);
        console.log("   - Role ID:", user.role_id);
        console.log("   - Role ID type:", typeof user.role_id);
        console.log("   - Role ID length:", user.role_id?.length);
        console.log("   - Location ID:", user.location_id);

        const [roles, locations] = await Promise.all([
          Role.list().catch(err => {
            console.error("🔐 SessionProvider: Error loading roles:", err);
            return [];
          }),
          Location.list().catch(err => {
            console.error("🔐 SessionProvider: Error loading locations:", err);
            return [];
          })
        ]);
        if (cancelled) return;

        console.log("🔐 SessionProvider: Roles disponibles en el sistema:", roles.length);
        
        // LOG DETALLADO DE CADA ROL
        roles.forEach(r => {
          console.log(`   - Rol: "${r.name}" ID: "${r.id}" (type: ${typeof r.id}, length: ${r.id?.length}) - Permisos: ${r.permissions?.length || 0}`);
        });

        let userRole = null;
        let permissions = [];
        let userLocation = null;

        // ADMIN tiene TODOS los permisos
        if (user.role === 'admin') {
          console.log("🔐 SessionProvider: ✅ Usuario es ADMIN");
          const allPerms = roles.flatMap(r => r.permissions || []);
          permissions = [...new Set(allPerms)];
          userRole = { name: 'Administrador', permissions };
          console.log("🔐 SessionProvider: Permisos de admin:", permissions.length, "permisos únicos");
        } 
        // Usuario con rol asignado - VALIDACIÓN MEJORADA
        else if (user.role_id && user.role_id !== '' && user.role_id !== 'null' && user.role_id !== 'undefined') {
          console.log("🔐 SessionProvider: 🔍 BUSCANDO ROL...");
          console.log("   - Buscando role_id:", `"${user.role_id}"`);
          console.log("   - En array de", roles.length, "roles");
          
          // COMPARACIÓN DETALLADA
          roles.forEach(r => {
            const match = r.id === user.role_id;
            const matchIgnoreCase = r.id?.toLowerCase() === user.role_id?.toLowerCase();
            const matchTrim = r.id?.trim() === user.role_id?.trim();
            console.log(`   📋 Comparando con "${r.name}": role.id="${r.id}" vs user.role_id="${user.role_id}"`);
            console.log(`      - Exact match: ${match}`);
            console.log(`      - Case-insensitive match: ${matchIgnoreCase}`);
            console.log(`      - Trimmed match: ${matchTrim}`);
          });
          
          const role = roles.find(r => r.id === user.role_id);
          
          if (role) {
            console.log("🔐 SessionProvider: ✅ Rol encontrado:", role.name);
            console.log("🔐 SessionProvider: Permisos del rol:", role.permissions?.length || 0);
            if (role.permissions && role.permissions.length > 0) {
              console.log("🔐 SessionProvider: Lista de permisos:", JSON.stringify(role.permissions));
            } else {
              console.warn("🔐 SessionProvider: ⚠️ EL ROL NO TIENE PERMISOS CONFIGURADOS");
            }
            userRole = role;
            permissions = Array.isArray(role.permissions) ? role.permissions : [];
          } else {
            console.error("🔐 SessionProvider: ❌ ROLE_ID NO ENCONTRADO EN LA LISTA DE ROLES");
            console.error("   - user.role_id:", `"${user.role_id}"`);
            console.error("   - IDs disponibles:", roles.map(r => `"${r.id}"`));
            console.error("   - ¿El rol fue eliminado o hay un error de tipeo?");
          }
        } else {
          console.warn("🔐 SessionProvider: ⚠️ USUARIO SIN ROL NI ROLE_ID ASIGNADO");
          console.warn("🔐 SessionProvider: user.role_id value:", user.role_id);
        }

        // Cargar ubicación del usuario
        if (user.location_id) {
          userLocation = locations.find(l => l.id === user.location_id);
          if (userLocation) {
            console.log("🔐 SessionProvider: ✅ Ubicación del usuario:", userLocation.name);
          } else {
            console.warn("🔐 SessionProvider: ⚠️ LOCATION_ID NO ENCONTRADA:", user.location_id);
          }
        } else {
          console.warn("🔐 SessionProvider: ⚠️ Usuario sin ubicación asignada");
        }

        if (cancelled) return;

        console.log("🔐 SessionProvider: ========== RESUMEN ==========");
        console.log("   - Usuario:", user.email);
        console.log("   - Rol:", userRole?.name || "SIN ROL");
        console.log("   - Permisos:", permissions);
        console.log("   - Cantidad de permisos:", permissions.length);
        console.log("   - Ubicación:", userLocation?.name || "SIN UBICACIÓN");
        console.log("🔐 SessionProvider: ========== FIN ==========");

        setState({
          currentUser: user,
          userRole,
          userLocation,
          permissions,
          isLoading: false,
          error: null
        });

      } catch (error) {
        if (cancelled) return;
        console.error("🔐 SessionProvider: ❌ ERROR CRÍTICO:", error);
        setState({
          currentUser: null,
          userRole: null,
          userLocation: null,
          permissions: [],
          isLoading: false,
          error: error.message
        });
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <SessionContext.Provider value={state}>
      {children}
    </SessionContext.Provider>
  );
}

export const useSession = () => {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useSession must be used within a SessionProvider');
  }
  return context;
};