import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, ShoppingCart, ShoppingBag, ArrowRightLeft, Wallet, CreditCard } from "lucide-react";

export default function BottomTabBar() {
  const location = useLocation();

  const handleTabClick = (e, tab) => {
    if (location.pathname === tab.path) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const tabs = [
    { 
      name: "Dashboard", 
      path: createPageUrl("Dashboard"), 
      icon: LayoutDashboard 
    },
    { 
      name: "Traslados", 
      path: createPageUrl("Transfers"), 
      icon: ArrowRightLeft 
    },
    { 
      name: "Compras", 
      path: createPageUrl("Purchases"), 
      icon: ShoppingBag 
    },
    { 
      name: "POS", 
      path: createPageUrl("POS"), 
      icon: ShoppingCart 
    },
    { 
      name: "Control de Efectivo", 
      path: createPageUrl("CashControl"), 
      icon: Wallet 
    },
    { 
      name: "Cuentas por Pagar", 
      path: createPageUrl("AccountsPayable"), 
      icon: CreditCard 
    },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-700 z-50 pb-safe">
      <div className="grid grid-cols-6 h-16">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location.pathname === tab.path;
          
          return (
            <Link
              key={tab.name}
              to={tab.path}
              onClick={(e) => handleTabClick(e, tab)}
              className={`flex flex-col items-center justify-center gap-1 transition-colors select-none ${
                isActive
                  ? "text-blue-600 dark:text-blue-400"
                  : "text-slate-600 dark:text-slate-400"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "scale-110" : ""}`} />
              <span className="text-xs font-medium">{tab.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}