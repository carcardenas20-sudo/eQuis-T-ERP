import React, { useState, useEffect } from "react";
import { useSession } from "../components/providers/SessionProvider";
import { Payment, Location, Expense, Credit } from "@/entities/all";
import { DollarSign, Wallet, Package, TrendingUp, CreditCard, AlertTriangle, Building2 } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Dashboard() {
  const { currentUser, userRole, userLocation, isLoading: isSessionLoading } = useSession();
  
  const [stats, setStats] = useState({
    totalIncome: 0,
    cashIncome: 0,
    cardIncome: 0,
    transferIncome: 0,
    totalExpenses: 0,
    cashExpenses: 0,
    netCashInDrawer: 0,
    pendingCredits: 0,
    overdueCredits: 0
  });
  
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isSessionLoading || !currentUser) return;
    
    const loadLocations = async () => {
      try {
        const locs = await Location.list();
        setLocations(locs);
        
        const isAdmin = currentUser.role === 'admin' || userRole?.name === 'Administrador';
        
        // ✅ FORZAR sucursal para usuarios no-admin
        if (!isAdmin && userLocation) {
          setSelectedLocation(userLocation.id);
        }
      } catch (error) {
        console.error("Error loading locations:", error);
      }
    };

    loadLocations();
  }, [isSessionLoading, currentUser, userRole, userLocation]);

  useEffect(() => {
    if (isSessionLoading || !currentUser) return;

    const loadStats = async () => {
      setIsLoading(true);
      
      try {
        const isAdmin = currentUser.role === 'admin' || userRole?.name === 'Administrador';
        
        let locationFilter = {};
        
        // ✅ FORZAR filtro de sucursal para usuarios no-admin
        if (!isAdmin && userLocation) {
          locationFilter = { location_id: userLocation.id };
          console.log("🔒 Dashboard - Usuario NO-admin, forzando sucursal:", userLocation.id);
        } else if (isAdmin && selectedLocation !== 'all') {
          locationFilter = { location_id: selectedLocation };
        }
        
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];

        const [todayPayments, todayExpenses, allCredits] = await Promise.all([
          Payment.filter(locationFilter),
          Expense.filter(locationFilter),
          Credit.filter(locationFilter)
        ]);

        const paymentsToday = todayPayments.filter(p => {
          const paymentDate = new Date(p.payment_date);
          const paymentDateStr = paymentDate.toISOString().split('T')[0];
          return paymentDateStr === todayStr;
        });

        const expensesToday = todayExpenses.filter(e => {
          return e.expense_date === todayStr;
        });

        const incomeByMethod = paymentsToday.reduce((acc, p) => {
          acc[p.method] = (acc[p.method] || 0) + (p.amount || 0);
          return acc;
        }, {});

        const totalIncome = Object.values(incomeByMethod).reduce((sum, amount) => sum + amount, 0);
        const cashIncome = incomeByMethod.cash || 0;
        const cardIncome = incomeByMethod.card || 0;
        const transferIncome = (incomeByMethod.transfer || 0) + (incomeByMethod.qr || 0);
        const cashExpenses = expensesToday
          .filter(e => e.payment_method === 'cash')
          .reduce((sum, e) => sum + (e.amount || 0), 0);
        const totalExpenses = expensesToday.reduce((sum, e) => sum + (e.amount || 0), 0);
        const netCashInDrawer = cashIncome - cashExpenses;

        const pendingCredits = allCredits
          .filter(c => (c.pending_amount || 0) > 0)
          .reduce((sum, c) => sum + (c.pending_amount || 0), 0);

        const overdueCredits = allCredits.filter(c => c.status === 'overdue').length;

        setStats({
          totalIncome,
          cashIncome,
          cardIncome,
          transferIncome,
          totalExpenses,
          cashExpenses,
          netCashInDrawer,
          pendingCredits,
          overdueCredits
        });

      } catch (error) {
        console.error("Error loading stats:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadStats();
  }, [selectedLocation, isSessionLoading, currentUser, userRole, userLocation]);

  if (isSessionLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  const isAdmin = currentUser?.role === 'admin' || userRole?.name === 'Administrador';

  return (
    <div className="p-4 sm:p-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen pb-24 sm:pb-8 overflow-y-auto">
      <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-3xl sm:text-3xl font-bold text-slate-900 mb-2">
            Dashboard
          </h1>
          <p className="text-slate-600 text-base sm:text-base">
            {currentUser?.full_name || currentUser?.email}
          </p>
          {/* ✅ NUEVO: Mostrar sucursal si es usuario no-admin */}
          {!isAdmin && userLocation && (
            <div className="mt-3 flex items-center gap-2 text-base text-blue-600">
              <Building2 className="w-5 h-5" />
              <span>Viendo datos de: <strong>{userLocation.name}</strong></span>
            </div>
          )}
        </div>

        {/* ✅ MODIFICADO: Solo admin puede cambiar sucursal */}
        {isAdmin && locations.length > 0 && (
          <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 mb-4 sm:mb-6">
            <label className="block text-base font-medium text-slate-700 mb-3">
              Filtrar por sucursal:
            </label>
            <Select value={selectedLocation} onValueChange={setSelectedLocation}>
              <SelectTrigger className="w-full h-12 text-base">
                <SelectValue placeholder="Seleccionar sucursal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-base py-3">Todas las Sucursales</SelectItem>
                {locations.map(loc => (
                  <SelectItem key={loc.id} value={loc.id} className="text-base py-3">
                    {loc.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* ✅ NUEVO: Alerta para usuarios no-admin */}
        {!isAdmin && (
          <Alert className="border-blue-200 bg-blue-50 p-4">
            <Building2 className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-700 text-base ml-2">
              Estás viendo únicamente los datos de tu sucursal asignada: <strong>{userLocation?.name}</strong>
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Efectivo en Caja</p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
                  ${stats.netCashInDrawer.toLocaleString()}
                </p>
              </div>
              <div className="bg-emerald-100 p-3 sm:p-3 rounded-xl">
                <Wallet className="w-7 h-7 sm:w-6 sm:h-6 text-emerald-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Ingresos Hoy</p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
                  ${stats.totalIncome.toLocaleString()}
                </p>
              </div>
              <div className="bg-blue-100 p-3 sm:p-3 rounded-xl">
                <DollarSign className="w-7 h-7 sm:w-6 sm:h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Gastos Hoy</p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
                  ${stats.totalExpenses.toLocaleString()}
                </p>
              </div>
              <div className="bg-purple-100 p-3 sm:p-3 rounded-xl">
                <Package className="w-7 h-7 sm:w-6 sm:h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Balance</p>
                <p className="text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
                  ${(stats.totalIncome - stats.totalExpenses).toLocaleString()}
                </p>
              </div>
              <div className="bg-amber-100 p-3 sm:p-3 rounded-xl">
                <TrendingUp className="w-7 h-7 sm:w-6 sm:h-6 text-amber-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Por Cobrar</p>
                <p className="text-2xl sm:text-3xl font-bold text-orange-600 tabular-nums">
                  ${stats.pendingCredits.toLocaleString()}
                </p>
              </div>
              <div className="bg-orange-100 p-3 sm:p-3 rounded-xl">
                <CreditCard className="w-7 h-7 sm:w-6 sm:h-6 text-orange-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-200">
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-base text-slate-600 mb-2">Vencidos</p>
                <p className="text-2xl sm:text-3xl font-bold text-red-600 tabular-nums">
                  {stats.overdueCredits}
                </p>
                <p className="text-sm sm:text-xs text-slate-500 mt-1">créditos</p>
              </div>
              <div className="bg-red-100 p-3 sm:p-3 rounded-xl">
                <AlertTriangle className="w-7 h-7 sm:w-6 sm:h-6 text-red-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Resumen de Cierre de Caja */}
        <div className="bg-white p-5 sm:p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg sm:text-xl font-semibold text-slate-900 mb-4">Cierre de Caja del Día</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="p-4 sm:p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm sm:text-xs text-green-700 mb-2 sm:mb-1">Efectivo</p>
              <p className="text-xl sm:text-2xl font-bold text-green-900 tabular-nums">${stats.cashIncome.toLocaleString()}</p>
            </div>
            <div className="p-4 sm:p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm sm:text-xs text-blue-700 mb-2 sm:mb-1">Tarjeta</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-900 tabular-nums">${stats.cardIncome.toLocaleString()}</p>
            </div>
            <div className="p-4 sm:p-4 bg-purple-50 rounded-lg border border-purple-200">
              <p className="text-sm sm:text-xs text-purple-700 mb-2 sm:mb-1">Transferencia</p>
              <p className="text-xl sm:text-2xl font-bold text-purple-900 tabular-nums">${stats.transferIncome.toLocaleString()}</p>
            </div>
            <div className="p-4 sm:p-4 bg-red-50 rounded-lg border border-red-200">
              <p className="text-sm sm:text-xs text-red-700 mb-2 sm:mb-1">Gastos</p>
              <p className="text-xl sm:text-2xl font-bold text-red-900 tabular-nums">${stats.totalExpenses.toLocaleString()}</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200">
            <div className="flex justify-between items-center">
              <span className="text-base sm:text-sm font-medium text-slate-700">Total Ventas del Día:</span>
              <span className="text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">${(stats.totalIncome + stats.totalExpenses).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}