import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/entities/User";
import { Plus, Loader2, AlertTriangle } from "lucide-react"; // Added AlertTriangle
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Edit, EyeOff, Eye, Trash2 } from "lucide-react";
import { Location } from "@/entities/Location";
import { Role } from "@/entities/Role";
import UserForm from "../components/users/UserForm";

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [locations, setLocations] = useState([]);
  const [roles, setRoles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [usersData, locationsData, rolesData] = await Promise.all([
        User.list("-created_date"),
        Location.list(),
        Role.list()
      ]);
      setUsers(usersData);
      setLocations(locationsData);
      setRoles(rolesData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleOpenEditForm = (user) => {
    console.log("👤 Editando usuario:", {
      email: user.email,
      current_role_id: user.role_id,
      role_id_type: typeof user.role_id
    });
    setEditingUser(user);
    setIsFormOpen(true);
  };
  
  const handleSaveUser = async (userData) => {
    setIsSaving(true);
    
    console.log("💾 ========== GUARDANDO USUARIO ==========");
    console.log("📝 Datos ANTES de procesar:", userData);
    
    try {
      // Destructure to separate special fields and collect the rest
      const { id, email, full_name, role, ...dataToUpdate } = userData; 
      
      // NO incluir campos built-in que el backend no debe recibir o puede causar errores
      if (dataToUpdate.created_date) delete dataToUpdate.created_date;
      if (dataToUpdate.updated_date) delete dataToUpdate.updated_date;
      if (dataToUpdate.created_by) delete dataToUpdate.created_by;
      
      if (dataToUpdate.salary) {
        dataToUpdate.salary = parseFloat(dataToUpdate.salary);
      }
      
      console.log("📝 Datos A ENVIAR (sin built-in):", dataToUpdate);
      console.log("📝 role_id que se va a guardar:", dataToUpdate.role_id);
      console.log("📝 role_id type:", typeof dataToUpdate.role_id);
      
      const updatedUser = await User.update(id, dataToUpdate);
      
      console.log("✅ Usuario guardado. Respuesta:", updatedUser);
      console.log("✅ Nuevo role_id en respuesta:", updatedUser.role_id);
      
      // Verificar si se actualizó el usuario actual
      const currentUser = await User.me();
      if (currentUser.email === email) { // Check if the updated user is the currently logged-in user
        console.log("🔄 SE MODIFICÓ EL USUARIO ACTUAL - FORZANDO LOGOUT");
        alert("Tu rol o datos sensibles han sido actualizados. La sesión se cerrará para aplicar los cambios.");
        
        setTimeout(async () => {
          await User.logout();
          window.location.reload();
        }, 2000); // Give user time to read the alert, then logout and reload
        
        return; // Stop further execution, especially closing the form or reloading data, as the page will reload
      }
      
      setIsFormOpen(false);
      setEditingUser(null);
      loadData();
      
      alert("Usuario actualizado exitosamente.");
      
    } catch (error) {
      console.error("❌ Error saving user:", error);
      console.error("❌ Error details:", error.message);
      alert("Error al guardar usuario: " + error.message);
    }
    setIsSaving(false);
  };

  const handleToggleActive = async (user) => {
    try {
      await User.update(user.id, { is_active: !user.is_active });
      loadData();
    } catch (error) {
      console.error("Error toggling user status:", error);
    }
  };

  const handleDeleteUser = async (user) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar al usuario "${user.full_name}"? Esta acción no se puede deshacer.`)) {
      try {
        await User.delete(user.id);
        loadData();
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };

  const getRoleName = (roleId) => {
    const role = roles.find(r => r.id === roleId);
    return role ? role.name : null;
  };

  const hasInvalidRole = (user) => {
    // A role is invalid if role_id exists but no matching role is found in the roles list
    return user.role_id && !roles.find(r => r.id === user.role_id);
  };

  return (
    <div className="p-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Gestión de Usuarios</h1>
            <p className="text-slate-600 mt-1">Administra los roles y accesos del personal.</p>
          </div>
          <Button disabled title="La creación de nuevos usuarios se gestiona desde el sistema de invitaciones de la plataforma" className="gap-2 cursor-not-allowed">
            <Plus className="w-5 h-5" />
            Nuevo Usuario
          </Button>
        </div>

        {/* Mobile cards */}
        <div className="md:hidden space-y-3">
          {isLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
          ) : (
            users.map((user) => {
              const roleName = getRoleName(user.role_id);
              const invalidRole = hasInvalidRole(user);
              const noRole = !user.role_id;
              const location = locations.find(l => l.id === user.location_id);
              return (
                <Card key={user.id} className={invalidRole || noRole ? 'bg-red-50 border-red-200' : 'border-0 shadow-sm'}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900">{user.full_name}</div>
                        <div className="text-sm text-slate-500 truncate max-w-[220px]">{user.email}</div>
                        {invalidRole && (
                          <div className="text-xs text-red-600 mt-1 font-mono">role_id: {user.role_id}</div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {invalidRole ? (
                          <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" /> Rol Inválido</Badge>
                        ) : noRole ? (
                          <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" /> Sin Rol</Badge>
                        ) : (
                          <Badge variant="secondary">{roleName}</Badge>
                        )}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleOpenEditForm(user)}>
                              <Edit className="w-4 h-4 mr-2" /> Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleToggleActive(user)}>
                              {user.is_active ? <><EyeOff className="w-4 h-4 mr-2" /> Desactivar</> : <><Eye className="w-4 h-4 mr-2" /> Activar</>}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => handleDeleteUser(user)} className="text-red-600">
                              <Trash2 className="w-4 h-4 mr-2" /> Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between text-sm">
                      <span className="text-slate-600">{location ? location.name : 'Sin asignar'}</span>
                      <Badge variant={user.is_active ? 'default' : 'destructive'} className={user.is_active ? 'bg-emerald-500' : ''}>
                        {user.is_active ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Desktop table */}
        <Card className="shadow-lg border-0 hidden md:block">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead>Nombre</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead>Sucursal</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-12">
                      <Loader2 className="w-8 h-8 mx-auto animate-spin text-blue-600" />
                    </TableCell>
                  </TableRow>
                ) : (
                  users.map((user) => {
                    const roleName = getRoleName(user.role_id);
                    const invalidRole = hasInvalidRole(user);
                    const noRole = !user.role_id;
                    const location = locations.find(l => l.id === user.location_id);
                    return (
                      <TableRow key={user.id} className={invalidRole || noRole ? 'bg-red-50' : ''}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div>
                              <div className="font-medium">{user.full_name}</div>
                              <div className="text-sm text-slate-500">{user.email}</div>
                              {invalidRole && (
                                <div className="text-xs text-red-600 mt-1 font-mono">role_id: {user.role_id}</div>
                              )}
                            </div>
                            {(invalidRole || noRole) && (
                              <AlertTriangle className="w-4 h-4 text-red-600" title="Rol inválido o faltante" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {invalidRole ? (
                            <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" /> Rol Inválido</Badge>
                          ) : noRole ? (
                            <Badge variant="destructive" className="gap-1"><AlertTriangle className="w-3 h-3" /> Sin Rol</Badge>
                          ) : (
                            <Badge variant="secondary">{roleName}</Badge>
                          )}
                        </TableCell>
                        <TableCell>{location ? <span className="text-sm">{location.name}</span> : <span className="text-sm text-slate-400">Sin asignar</span>}</TableCell>
                        <TableCell>
                          <Badge variant={user.is_active ? 'default' : 'destructive'} className={user.is_active ? 'bg-emerald-500' : ''}>
                            {user.is_active ? 'Activo' : 'Inactivo'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleOpenEditForm(user)}>
                                <Edit className="w-4 h-4 mr-2" /> Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleToggleActive(user)}>
                                {user.is_active ? <><EyeOff className="w-4 h-4 mr-2" /> Desactivar</> : <><Eye className="w-4 h-4 mr-2" /> Activar</>}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handleDeleteUser(user)} className="text-red-600">
                                <Trash2 className="w-4 h-4 mr-2" /> Eliminar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {isFormOpen && editingUser && (
        <UserForm
          user={editingUser}
          locations={locations}
          roles={roles} // Pass roles to UserForm
          onSave={handleSaveUser}
          onCancel={() => setIsFormOpen(false)}
          isSaving={isSaving}
        />
      )}
    </div>
  );
}