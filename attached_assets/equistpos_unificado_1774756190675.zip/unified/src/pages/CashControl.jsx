import React, { useState, useEffect, useCallback } from "react";
import { CashControl, Payment, Expense, Location } from "@/entities/all";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  ChevronDown,
  ChevronUp
} from "lucide-react";

function formatDate(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${day}/${month}/${year} ${hours}:${minutes}`;
}

function formatDateDisplay(dateStr) {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  const date = new Date(year, month - 1, day);
  const days = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  return `${days[date.getDay()]}, ${day} ${months[date.getMonth()]} ${year}`;
}

function formatShort(n) {
  const num = Number(n) || 0;
  const abs = Math.abs(num);
  const fmt = (value) => value.toFixed(value % 1 === 0 ? 0 : 1).replace(/\.0$/, '');
  if (abs >= 1_000_000_000) return fmt(num / 1_000_000_000) + 'B';
  if (abs >= 1_000_000) return fmt(num / 1_000_000) + 'M';
  if (abs >= 1_000) return fmt(num / 1_000) + 'k';
  return num.toLocaleString();
}

export default function CashControlPage() {
  const [controls, setControls] = useState([]);
  const [locations, setLocations] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    location: "all",
    dateRange: "week"
  });
  const [editingControl, setEditingControl] = useState(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [expandedDates, setExpandedDates] = useState({});

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [user, locs] = await Promise.all([
        User.me(),
        Location.filter({ is_active: true })
      ]);
      
      setCurrentUser(user);
      setLocations(locs);

      const today = new Date();
      let startDate = new Date(today);
      
      if (filters.dateRange === 'week') {
        startDate.setDate(startDate.getDate() - 7);
      } else if (filters.dateRange === 'month') {
        startDate.setDate(startDate.getDate() - 30);
      }

      const applyDateFilter = filters.dateRange !== 'all';
      const startStr = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`;

      let paymentsFilter = {};
      let expensesFilter = {};
      
      if (filters.location !== "all") {
        paymentsFilter.location_id = filters.location;
        expensesFilter.location_id = filters.location;
      }

      const [payments, expenses] = await Promise.all([
        Payment.filter(paymentsFilter),
        Expense.filter(expensesFilter)
      ]);

      const dataByDate = {};

      payments.forEach(payment => {
        const date = payment.payment_date ? payment.payment_date.split('T')[0] : null;
        if (!date) return;
        if (applyDateFilter && date < startStr) return;
        
        const key = `${date}_${payment.location_id}`;
        
        if (!dataByDate[key]) {
          dataByDate[key] = {
            date,
            location_id: payment.location_id,
            cash: 0,
            transfers: 0,
            card: 0,
            expenses: []
          };
        }

        if (payment.method === 'cash') {
          dataByDate[key].cash += payment.amount || 0;
        } else if (payment.method === 'transfer' || payment.method === 'qr') {
          dataByDate[key].transfers += payment.amount || 0;
        } else if (payment.method === 'card') {
          dataByDate[key].card += payment.amount || 0;
        }
      });

      expenses.forEach(expense => {
        const date = expense.expense_date;
        if (!date) return;
        if (applyDateFilter && date < startStr) return;
        
        const key = `${date}_${expense.location_id}`;
        
        if (!dataByDate[key]) {
          dataByDate[key] = {
            date,
            location_id: expense.location_id,
            cash: 0,
            transfers: 0,
            card: 0,
            expenses: []
          };
        }

        if (expense.payment_method === 'cash') {
          dataByDate[key].cash -= expense.amount || 0;
          dataByDate[key].expenses.push(expense);
        }
      });

      const existingControls = await CashControl.list();
      const controlsArray = [];
      const updatePromises = [];

      for (const [key, data] of Object.entries(dataByDate)) {
        let control = existingControls.find(
          c => c.control_date === data.date && c.location_id === data.location_id
        );

        if (control) {
          // Solo actualizar si los valores han cambiado
          if (control.cash_amount !== data.cash || control.transfer_amount !== data.transfers || control.card_amount !== data.card) {
            updatePromises.push(
              CashControl.update(control.id, {
                cash_amount: data.cash,
                transfer_amount: data.transfers,
                card_amount: data.card
              })
            );
          }
          control = { ...control, cash_amount: data.cash, transfer_amount: data.transfers, card_amount: data.card };
        } else {
          control = await CashControl.create({
            location_id: data.location_id,
            control_date: data.date,
            cash_amount: data.cash,
            transfer_amount: data.transfers,
            card_amount: data.card,
            cash_collected: false,
            transfers_verified: false
          });
        }

        controlsArray.push({ ...control, expenses: data.expenses });
      }

      // Ejecutar todas las actualizaciones en paralelo con límite de concurrencia
      if (updatePromises.length > 0) {
        await Promise.all(updatePromises);
      }

      controlsArray.sort((a, b) => new Date(b.control_date) - new Date(a.control_date));
      setControls(controlsArray);

    } catch (error) {
      console.error("Error:", error);
    }
    setIsLoading(false);
  }, [filters]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleMarkCashCollected = async (control) => {
    try {
      await CashControl.update(control.id, {
        cash_collected: true,
        cash_collected_date: new Date().toISOString(),
        cash_collected_by: currentUser.email
      });
      loadData();
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const handleMarkTransfersVerified = async (control) => {
    try {
      await CashControl.update(control.id, {
        transfers_verified: true,
        transfers_verified_date: new Date().toISOString(),
        transfers_verified_by: currentUser.email
      });
      loadData();
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const handleSaveNotes = async () => {
    if (!editingControl) return;
    try {
      await CashControl.update(editingControl.id, {
        notes: editingControl.notes
      });
      setShowNotesModal(false);
      setEditingControl(null);
      loadData();
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const toggleDate = (key) => {
    setExpandedDates(prev => ({ ...prev, [key]: !prev[key] }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  const byDate = {};
  controls.forEach(c => {
    const key = c.control_date;
    if (!byDate[key]) byDate[key] = [];
    byDate[key].push(c);
  });

  const pending = Object.keys(byDate).filter(k => 
    byDate[k].some(c => !c.cash_collected || !c.transfers_verified)
  ).sort((a, b) => new Date(b) - new Date(a));

  const completed = Object.keys(byDate).filter(k => 
    byDate[k].every(c => c.cash_collected && c.transfers_verified)
  ).sort((a, b) => new Date(b) - new Date(a));

  const controlsForKPI = controls.filter(c => filters.location === 'all' || c.location_id === filters.location);
  const uncollectedTotal = controlsForKPI
    .filter(c => !c.cash_collected)
    .reduce((sum, c) => {
      const expensesTotal = (c.expenses || []).reduce((s, e) => s + (e.amount || 0), 0);
      const netCash = (c.cash_amount || 0) - expensesTotal; // efectivo después de gastos
      return sum + Math.max(netCash, 0);
    }, 0);
  const selectedLocationName = filters.location === 'all'
    ? 'Todas'
    : (locations.find(l => l.id === filters.location)?.name || 'Sucursal');

  return (
    <div className="p-6 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Control de Efectivo</h1>

        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-2 gap-4">
              <Select value={filters.location} onValueChange={(v) => setFilters(p => ({ ...p, location: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {locations.map(l => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}
                </SelectContent>
              </Select>

              <Select value={filters.dateRange} onValueChange={(v) => setFilters(p => ({ ...p, dateRange: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Semana</SelectItem>
                  <SelectItem value="month">Mes</SelectItem>
                  <SelectItem value="all">Todos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-200 bg-emerald-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-emerald-700">Efectivo sin recoger</div>
                <div className="text-3xl font-extrabold text-emerald-900 tabular-nums">
                  {uncollectedTotal.toLocaleString()}
                </div>
                <div className="text-xs text-emerald-700 mt-1">
                  Sucursal: {selectedLocationName}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {pending.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">⏳ Pendientes ({pending.length})</h2>
            {pending.map(date => (
              <Card key={date}>
                <CardHeader className="cursor-pointer" onClick={() => toggleDate(date)}>
                  <div className="flex justify-between items-center">
                    <CardTitle>{formatDateDisplay(date)}</CardTitle>
                    {expandedDates[date] ? <ChevronUp /> : <ChevronDown />}
                  </div>
                </CardHeader>
                {expandedDates[date] && (
                  <CardContent>
                    {byDate[date].map(c => {
                      const loc = locations.find(l => l.id === c.location_id);
                      return (
                        <div key={c.id} className="p-4 bg-slate-50 rounded mb-3">
                         <h3 className="font-bold mb-3">{loc?.name}</h3>

                         {/* Resumen de Cierre de Caja */}
                         <div className="mb-4 p-4 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg border-2 border-slate-300">
                           <h4 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                             📊 Resumen del Día
                           </h4>
                           <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                             <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50">
                               <div className="text-slate-700 text-xs">💵 Efectivo</div>
                               <div className="mt-1 text-base sm:text-lg font-extrabold text-emerald-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.cash_amount || 0)}</div>
                             </div>
                             <div className="p-3 rounded-xl border border-blue-200 bg-blue-50">
                               <div className="text-slate-700 text-xs">💳 Tarjeta</div>
                               <div className="mt-1 text-base sm:text-lg font-extrabold text-blue-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.card_amount || 0)}</div>
                             </div>
                             <div className="p-3 rounded-xl border border-purple-200 bg-purple-50">
                               <div className="text-slate-700 text-xs">🏦 Transferencia</div>
                               <div className="mt-1 text-base sm:text-lg font-extrabold text-purple-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.transfer_amount || 0)}</div>
                             </div>
                             <div className="p-3 rounded-xl border border-red-200 bg-red-50">
                               <div className="text-slate-700 text-xs">💸 Gastos</div>
                               <div className="mt-1 text-base sm:text-lg font-extrabold text-red-600 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort((c.expenses || []).reduce((sum, e) => sum + (e.amount || 0), 0))}</div>
                             </div>
                           </div>
                           <div className="pt-3 border-t-2 border-slate-300">
                             <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                               <span className="font-bold text-slate-800">Total Ventas del Día:</span>
                               <span className="text-xl font-extrabold text-slate-900 tabular-nums">
                                 ${(((c.cash_amount || 0) + (c.card_amount || 0) + (c.transfer_amount || 0)) + ((c.expenses || []).reduce((sum, e) => sum + (e.amount || 0), 0))).toLocaleString()}
                               </span>
                             </div>
                           </div>
                         </div>

                         {c.expenses && c.expenses.length > 0 && (
                           <div className="mb-3 p-3 bg-red-50 rounded">
                             <p className="font-semibold text-red-800 mb-2">Detalle de Gastos:</p>
                             {c.expenses.map((e, i) => (
                               <div key={i} className="text-sm">{e.description}: ${e.amount?.toLocaleString()}</div>
                             ))}
                           </div>
                         )}

                         <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div className="p-3 bg-white rounded">
                              <div className="flex justify-between mb-2">
                                <span>Efectivo</span>
                                <span className="font-bold text-green-600">${(c.cash_amount || 0).toLocaleString()}</span>
                              </div>
                              {c.cash_collected ? (
                                <Badge className="bg-green-500">Recogido</Badge>
                              ) : (
                                <Button size="sm" onClick={() => handleMarkCashCollected(c)} className="w-full">
                                  Marcar Recogido
                                </Button>
                              )}
                            </div>

                            <div className="p-3 bg-white rounded">
                              <div className="flex justify-between mb-2">
                                <span>Transferencias</span>
                                <span className="font-bold text-blue-600">${(c.transfer_amount || 0).toLocaleString()}</span>
                              </div>
                              {c.transfers_verified ? (
                                <Badge className="bg-blue-500">Verificado</Badge>
                              ) : (
                                <Button size="sm" onClick={() => handleMarkTransfersVerified(c)} className="w-full">
                                  Marcar Verificado
                                </Button>
                              )}
                            </div>

                            <div className="p-3 bg-slate-100 rounded">
                              <div className="flex justify-between mb-2">
                                <span className="text-sm text-slate-600">Tarjeta</span>
                                <span className="font-bold text-slate-700">${(c.card_amount || 0).toLocaleString()}</span>
                              </div>
                              <Badge variant="outline" className="text-xs">Informativo</Badge>
                            </div>
                          </div>

                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full mt-3"
                            onClick={() => {
                              setEditingControl(c);
                              setShowNotesModal(true);
                            }}
                          >
                            {c.notes ? 'Ver Notas' : 'Agregar Notas'}
                          </Button>
                        </div>
                      );
                    })}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}

        {completed.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold">✅ Completados ({completed.length})</h2>
            {completed.map(date => (
              <Card key={date}>
                <CardHeader className="cursor-pointer" onClick={() => toggleDate(date)}>
                  <div className="flex justify-between items-center">
                    <CardTitle>{formatDateDisplay(date)}</CardTitle>
                    {expandedDates[date] ? <ChevronUp /> : <ChevronDown />}
                  </div>
                </CardHeader>
                {expandedDates[date] && (
                  <CardContent>
                    {byDate[date].map(c => {
                      const loc = locations.find(l => l.id === c.location_id);
                      return (
                        <div key={c.id} className="p-4 rounded-xl border bg-white shadow-sm mb-3">
                          <h3 className="font-bold mb-3">{loc?.name}</h3>
                          <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                            <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50">
                              <div className="text-slate-700 text-xs">💵 Efectivo</div>
                              <div className="mt-1 text-base sm:text-lg font-extrabold text-emerald-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.cash_amount || 0)}</div>
                            </div>
                            <div className="p-3 rounded-xl border border-blue-200 bg-blue-50">
                              <div className="text-slate-700 text-xs">💳 Tarjeta</div>
                              <div className="mt-1 text-base sm:text-lg font-extrabold text-blue-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.card_amount || 0)}</div>
                            </div>
                            <div className="p-3 rounded-xl border border-purple-200 bg-purple-50">
                              <div className="text-slate-700 text-xs">🏦 Transferencia</div>
                              <div className="mt-1 text-base sm:text-lg font-extrabold text-purple-700 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort(c.transfer_amount || 0)}</div>
                            </div>
                            <div className="p-3 rounded-xl border border-red-200 bg-red-50">
                              <div className="text-slate-700 text-xs">💸 Gastos</div>
                              <div className="mt-1 text-base sm:text-lg font-extrabold text-red-600 tabular-nums text-right whitespace-nowrap overflow-hidden text-ellipsis leading-none">${formatShort((c.expenses || []).reduce((sum, e) => sum + (e.amount || 0), 0))}</div>
                            </div>
                          </div>
                          <div className="pt-3 border-t">
                            <div className="flex justify-between items-center p-3 rounded-lg bg-white">
                              <span className="text-slate-800 font-semibold">Total Ventas del Día:</span>
                              <span className="text-xl font-extrabold text-slate-900 tabular-nums">
                                ${formatShort((c.cash_amount || 0) + (c.card_amount || 0) + (c.transfer_amount || 0) + ((c.expenses || []).reduce((sum, e) => sum + (e.amount || 0), 0)))}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={showNotesModal} onOpenChange={setShowNotesModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Notas</DialogTitle>
          </DialogHeader>
          <Textarea
            value={editingControl?.notes || ''}
            onChange={(e) => setEditingControl(p => ({ ...p, notes: e.target.value }))}
            rows={6}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNotesModal(false)}>Cancelar</Button>
            <Button onClick={handleSaveNotes}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}