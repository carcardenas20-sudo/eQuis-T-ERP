import React, { useState, useEffect } from "react";
import { Product } from "@/entities/Product";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, Package } from "lucide-react";

import ProductForm from "../components/products/ProductForm";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    try {
      const data = await Product.list();
      setProducts(data || []);
    } catch (err) {
      console.error("Error:", err);
      setProducts([]);
    }
    setLoading(false);
  };

  const handleSubmit = async (productData) => {
    try {
      if (editingProduct) {
        await Product.update(editingProduct.id, productData);
      } else {
        await Product.create(productData);
      }
      setShowForm(false);
      setEditingProduct(null);
      loadProducts();
    } catch (error) {
      console.error("Error saving product:", error);
      alert("Error al guardar el producto.");
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setShowForm(true);
  };

  const handleDelete = async (product) => {
    if (window.confirm(`¿Estás seguro de eliminar el producto ${product.name}?`)) {
      try {
        await Product.delete(product.id);
        loadProducts();
      } catch (error) {
        console.error("Error deleting product:", error);
        alert("Error al eliminar el producto.");
      }
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingProduct(null);
  };

  if (loading) {
    return (
      <div className="p-6 bg-slate-50 min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Productos</h1>
            <p className="text-slate-600">Gestiona el catálogo de productos</p>
          </div>
          <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Producto
          </Button>
        </div>

        {showForm && (
          <ProductForm
            product={editingProduct}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
          />
        )}

        <Card>
          <CardHeader>
            <CardTitle>Catálogo de Productos ({products.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {products.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {products.map(product => (
                  <Card key={product.id} className="border-slate-200 hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-bold text-slate-900 text-lg mb-1">{product.name}</h3>
                          <p className="text-sm text-slate-600 font-medium">Ref: {product.reference}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(product)}
                            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(product)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="text-center bg-green-50 py-3 rounded-lg">
                          <p className="text-2xl font-bold text-green-700">
                            ${product.manufacturing_price?.toLocaleString()}
                          </p>
                          <p className="text-xs text-green-600">Precio de manufactura</p>
                        </div>

                        {product.category && (
                          <div className="flex justify-center">
                            <Badge className="bg-purple-100 text-purple-800">
                              {product.category}
                            </Badge>
                          </div>
                        )}

                        {product.description && (
                          <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                            {product.description}
                          </p>
                        )}

                        <div className="flex justify-center">
                          <Badge className={product.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                            {product.is_active ? 'Activo' : 'Inactivo'}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                <Package className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg">No hay productos registrados.</p>
                <p className="text-sm">Crea el primer producto para comenzar.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}